# cloud-server
Deploy a simple Node.js server to EC2, using Elastic Beanstalk
